'use strict'

// Variables login
const emailLogin = document.getElementById('emailLogin')
const passwordLogin = document.getElementById('passwordLogin')
const btnlogin = document.getElementById('btnLogin')




// Funcion autenticar por email enviado a cuenta
let autenticar = () => {
    let user = firebase.auth().currentUser
    user.sendEmailVerification().then(function () {
        // Email sent.
        console.log('Enviando mensaje')
    }).catch(function (error) {
        // An error happened.
        console.log(error)
    });
}

    //Logar usuario
    async function login( ){
        await firebase.auth().signInWithEmailAndPassword(emailLogin.value, passwordLogin.value)
        .then(async (value)=>{
            let uid = value.user.uid;
            await firebase.database().ref('users').child(uid).once('value')
            .then((snapshot)=>{
                let data = {
                  uid: uid,
                  nome: snapshot.val().nome,
                  displayName: snapshot.val().displayName,
                  tipo: snapshot.val().tipo,
                  sobrenome: snapshot.val().sobrenome,
                  ano: snapshot.val().ano,
                  nomepai: snapshot.val().nomepai,
                  nomemae: snapshot.val().nomemae,
                  endereco: snapshot.val().endereco,
                  estatura: snapshot.val().estatura,
                  peso: snapshot.val().peso,
                  posicao: snapshot.val().posicao,
                  pratic: snapshot.val().pratic,
                  pratictime: snapshot.val().pratictime,
                  estudos: snapshot.val().estudos,
                  curso: snapshot.val().curso,
                  instnome: snapshot.val().instnome,
                  profissional: snapshot.val().profissional,
                  email: value.user.email,
                };
                containerInfoLogin(data);
               
               


            })

            
        })
        .catch((error)=> {
            alert('ola');
        });

    }

    

// Funcion observable de usuarios activos.
let observable = () => {
    firebase.auth().onAuthStateChanged(function (user) {
        if (user) {
            console.log('Existe usuario activo')
            containerInfoLogin(user)
            // User is signed in.
            var displayName = user.displayName;
            var email = user.email;
            var emailVerified = user.emailVerified;
            var photoURL = user.photoURL;
            var isAnonymous = user.isAnonymous;
            var uid = uid;
            var providerData = user.providerData;
            console.log(user.emailVerified)
            containerInfoLogin(email)
            // ...
        } else {
            console.log('no existe usuario activo')
            // User is signed out.
            // ...
        }
    });
}

function redirecioneComHistorico() {
    // Faz um redirecionamento mantendo a página original no histórico de navegaçãodo browser.
    window.location.replace("./dist/index.html");
}

// Funcion que muestra informacion del login
let containerInfoLogin = (user) => {
    console.log(user)
    let containerUserLoged = document.getElementById('containerDates')
    //let user = user
    if (user.email) {
        containerUserLoged.innerHTML =  `
        <div style="
        display: flex;
        width:100%;
        height: 80px;
        margin: 6px;
        background-color: #1f1d2b;
        border-radius: 12px;
        position: absolute;
        align-items: center;
        justify-content: start;
        flex-direction: row;
        padding-left: 30px;
        z-index: 20;
        top:1px;
        right: 0px;
        ">
             <div style="
             width: 80px;
             height: 80px;
             border-radius: 40px;
             background-color: #4e4b6389;
             "></div> 

                <div style="
                display: flex;
                justify-content: start;
                align-items: center;
                border-radius: 12px;
                margin-left: 2%;
                padding: 6px;
                width: 80%;
                height: 100%;
                background-color: #2a27399f;
                "> 
                    
                    <a onclick="redirecioneComHistorico()" class="btn btn-block btn-danger" id="btnlogin">Visualizar seu perfil</a>
                </div>
            </div>
        </div>
    `
    }

}

// Funcion para cerrar sesión 
//let logout = () => {
 //   console.log('Saliendo..')
  //  firebase.auth().signOut().then(function () {
  //      console.log('Saliendo...')
   // })
    //    .catch(function (error) {
      //      console.log(error)
      //  })
//}


// Evento para registrar 
//btnregistro.addEventListener('click', register)

// Evento para logear
btnlogin.addEventListener('click', login)

// Evento observador
window.addEventListener('load', observable);

// Evento para cerrar sesión
//btnlogout.addEventListener('click', logout);